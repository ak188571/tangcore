Console138K UART 8 Mbit/s 受信・SDRAM並行化 実機確認済みtrace版

共通tag: uart8-overlap-hw-20261108
firmware: firmware/trace/tangcore_bl616.bin
core: cores/console138k/snestang.bin
対応する組を使用し、保存・照合後にBL616 firmware領域0x40000へ適用します。
source commitはrelease-manifest.json、各収録ファイルの照合値はSHA256SUMSを参照してください。
通常版の起動・下段表示・一覧復帰を2本で確認済み。通常版は再計時していません。
