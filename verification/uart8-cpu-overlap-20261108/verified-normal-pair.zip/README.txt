Console138K UART8 CPU重ね合わせ 実機確認済み normal版
共通tag: uart8-cpu-overlap-hw-20261108
firmware: firmware/normal/tangcore_bl616.bin
core: cores/console138k/snestang.bin
通常版は軽量計測・詳細計測ともOFF。計測版も詳細計測はOFF。
既存flashとmicroSDを保存・照合してから、対応する組を使用してください。
BL616はfirmware領域0x40000へ適用し、全flashの消去・書換えには使用しません。
source commitはrelease-manifest.json、収録ファイルの照合値はSHA256SUMSを参照してください。
通常版の起動・下段表示・一覧復帰を2 MiB・4 MiBで確認済み。通常版では再計時していません。
