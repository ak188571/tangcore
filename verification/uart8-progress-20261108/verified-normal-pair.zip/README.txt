Console138K UART 8 Mbit/s 実機確認済み通常版

firmware/normal/tangcore_bl616.bin をBL616のfirmware領域（0x40000）へ適用し、cores/console138k/snestang.bin をmicroSDの同じ場所に配置します。
通常版での起動とロード中の表示は利用者が実機で確認済みです。
source commitとSHA-256は release-manifest.json、各ファイルの照合値はSHA256SUMSにあります。
